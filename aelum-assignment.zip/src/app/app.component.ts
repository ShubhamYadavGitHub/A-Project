import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SearchCountryField, CountryISO, PhoneNumberFormat } from 'ngx-intl-tel-input';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'aelum-assignment';
  minute: any;
  second: any;
  UserForm: FormGroup;
  isError: boolean = false;
  data: any = [];

  separateDialCode = false;
  SearchCountryField = SearchCountryField;
  CountryISO = CountryISO;
  PhoneNumberFormat = PhoneNumberFormat;
  preferredCountries: CountryISO[] = [CountryISO.UnitedStates, CountryISO.UnitedKingdom];
  // phoneForm = new FormGroup({
  // 	phone: ('', [Validators.required])
  // });
  model: any;
  changePreferredCountries() {
    this.preferredCountries = [CountryISO.India, CountryISO.Canada];
  }
  constructor(private fb: FormBuilder) {
    this.UserForm = this.fb.group({
      fullname: ['', Validators.required],
      email: ['', Validators.required],
      dob: ['', Validators.required],
      address: ['', Validators.required],
      phone: ['', Validators.required]
    });


  }



  timer() {

    this.minute = '05';
    this.second = '00';
    setInterval(() => {
      if (this.second == '00') {
       
        if (this.minute == 0 && this.second == 0) {
          alert(" Ooops Time is up !!");
          this.UserForm.reset();
          window.location.reload();
        }
        this.second = 60;
        this.minute--;
     
      }
      this.second--;
    }, 1000);
  }
  key(data: any) {
    alert(data.target.value)
  }
  ngOnInit() {

    
    this.timer();
  }

  telInputObject(data: any) {
    console.log(data);
    console.log(data);
    data.setCountry('in');
  }
  onCountryChange(data: any) {
    console.log(data);

  }
  getNumber(data: any) {
    console.log(data);

  }

  submit() {
    alert('hi')

    if (this.UserForm.valid) {
      console.log(this.UserForm.value);

      this.data.push(this.UserForm.value);
      this.timer();
    }

    alert("Fill the details correctly");

  }

  reset() {
    this.UserForm.reset();
    this.timer();
  }
}
